<head>
  <body onclick="generate()">
    <div id="user-input" class="inline">
      <input type="text" id="submit" />
    </div>
  </body>
</head>;